const CreateUserHandler = require("./handler/create_user_handler");
const GetUsersHandler = require("./handler/get_users_handler");

class ServiceRouteRest {
  constructor() {
    this.createUserHandler = new CreateUserHandler();
    this.getUsersHandler = new GetUsersHandler();
  }

  async getUsers(event) {
    return await this.getUsersHandler.handler(event);
  }

  async createUser(event) {
    return await this.createUserHandler.handler(event);
  }
}

module.exports = ServiceRouteRest;
