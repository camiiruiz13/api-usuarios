const ServiceRouteRest = require('./infraestructure/entry-points/service_route_rest');
const serviceRouteRest = new ServiceRouteRest();

module.exports.getUsers = async (event) => {
  return serviceRouteRest.getUsers(event);
};

module.exports.createUser = async (event) => {
  return serviceRouteRest.createUser(event);
};


